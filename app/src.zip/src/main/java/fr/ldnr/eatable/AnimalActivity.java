package fr.ldnr.eatable;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.List;

public class AnimalActivity extends Activity implements View.OnClickListener {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animal);
        Button buttonAnimal = findViewById(R.id.btAnimal);
        buttonAnimal.setOnClickListener(this);
        String[] animaux = getResources().getStringArray(R.array.list_animaux);
        AutoCompleteTextView etAnimaux = findViewById(R.id.et_animal_espece);
        ArrayAdapter<String> aa = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, animaux);
        etAnimaux.setAdapter(aa);
    }

    @Override
    public void onClick(View v) {
        EditText etNomAnimal = findViewById(R.id.et_animal_nom);
        EditText etTypeAnimal = findViewById(R.id.et_animal_espece);
        EditText etAgeAnimal = findViewById(R.id.et_animal_age);

        if(etNomAnimal.getText().toString().isEmpty() || etTypeAnimal.getText().toString().isEmpty()
                || etAgeAnimal.getText().toString().isEmpty()){
            Toast.makeText(this, "Veuillez remplir tous les paramètres",
                    Toast.LENGTH_LONG).show();
        }else {
            String message = "L'animal : " + etNomAnimal.getText() + " a : " + etAgeAnimal.getText()
                    + " an(s) et est un(e) : " + etTypeAnimal.getText();
            Log.i("AnimalActivity", message);
            OceanHelper oh = new OceanHelper(this);
            int result = oh.insererAnimal(etNomAnimal.getText().toString(),
                    Integer.parseInt(etAgeAnimal.getText().toString()), etTypeAnimal.getText().toString());
            Log.i("AnimalActivity" ,"le resultat est : " + result);
            List<String> animaux = oh.getAnimaux();

            for (String animal: animaux){
                Log.i("AnimalActivity", "L'animal : "+ animal);
            }

            etNomAnimal.setText("");
            etAgeAnimal.setText("");
            etTypeAnimal.setText("");
        }
    }
}
